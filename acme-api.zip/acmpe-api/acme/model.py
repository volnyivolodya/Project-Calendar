class Calendar:
    date: datetime.date
    title: str
    text: str